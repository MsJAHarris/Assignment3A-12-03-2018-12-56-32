# Problem Description:
# # Please create a flowchart, IPO chart and trace table for a particular error you had while creating
# # your work.  Please let me know which version you were on at the time of the error, so that I may see
# # the code and match up the trace table to that (now fixed) code.
# #
# # Your task: Create a basic Yatzee game (top of score card only) using the msdie class created in class.
# # Note: Rename this file appropriately (if that does not happen automatically)
# # Date Begun:
#
# # Programmer:
#

import pygame
import random
import time

p = pygame

#initialize
p.init()
p.font.init()

# colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
GRAY = (128, 128, 128)
DGRAY = (48, 48, 48)

#font
myfont = pygame.font.SysFont('monospace', 15)

# setting up the screen
(width, height) = (600, 600)

#setting up display
display = p.display
w, h = (600, 600)
screen = display.set_mode((w, h))
display.set_caption("Thomas Ingram A2Q3 - Yahtzee")

# running variable
running = True
rolls = 3

def text_to_screen(text, x, y, color=BLACK, center=True):
    textSurf = myfont.render(text, 1, color)
    if center == True:
        screen.blit(textSurf, (x-textSurf.get_width()/2, y-textSurf.get_height()/2))#draw it
    else:
        screen.blit(textSurf, (x, y))

class Dice(pygame.sprite.Sprite):#dice class
    def __init__(self, x, y):
        super().__init__()#init sprite
        self.value = random.randint(1, 6)#setting variables
        self.diceSides = {1:self.one, 2:self.two, 3:self.three, 4:self.four, 5:self.five, 6:self.six}
        self.x = x
        self.y = y
        self.locked = False

    def roll(self):#method to roll dice
        self.value = random.randint(1, 6)#choose a value
        self.update()#update the dice

    def update(self):
        mouse = p.mouse.get_pos()#get mouse pos
        drawSurface = pygame.Surface((600, 600))#create a new suface
        self.diceSides[self.value](drawSurface)#call the draw function stored in the dict
        drawSurface = pygame.transform.scale(drawSurface, (100, 100))#scale the surface

        if (self.x + 100 > mouse[0] > self.x) and (self.y + 100 > mouse[1] > self.y):#if the mouse is over top of it
            pygame.draw.rect(drawSurface, BLACK, (0, 0, 598, 598), 10)  # Draws the background (locked/hovered)

        if(self.locked):#if it is locked
            pygame.draw.rect(drawSurface, BLACK, (0, 0, 598, 598), 10)  # Draws the background (locked/hovered)

        screen.blit(drawSurface, (self.x, self.y))#draw it to screen

    def one(self, surface):#method to draw one die
        surface.fill(BLACK)
        pygame.draw.rect(surface, WHITE, (10, 10, 575, 575))  # Draws the background
        pygame.draw.circle(surface, BLACK, (300, 300), 50)  # Draws one BLACK dot in center

    def two(self, surface):#method to draw two die
        surface.fill(BLACK)
        pygame.draw.rect(surface, WHITE, (10, 10, 575, 575))  # Draws the background
        pygame.draw.circle(surface, BLACK, (200, 300), 50)
        pygame.draw.circle(surface, BLACK, (400, 300), 50)

    def three(self, surface):#method to draw three die
        surface.fill(BLACK)
        pygame.draw.rect(surface, WHITE, (10, 10, 575, 575))  # Draws the background
        pygame.draw.circle(surface, BLACK, (300, 400), (50))
        pygame.draw.circle(surface, BLACK, (200, 200), (50))
        pygame.draw.circle(surface, BLACK, (400, 200), (50))

    def four(self, surface):#method to draw four die
        surface.fill(BLACK)
        pygame.draw.rect(surface, WHITE, (10, 10, 575, 575))  # Draws the background
        pygame.draw.circle(surface, BLACK, (200, 200), 50)
        pygame.draw.circle(surface, BLACK, (400, 400), 50)
        pygame.draw.circle(surface, BLACK, (200, 400), 50)
        pygame.draw.circle(surface, BLACK, (400, 200), 50)

    def five(self, surface):#method to draw five die
        surface.fill(BLACK)
        pygame.draw.rect(surface, WHITE, (10, 10, 575, 575))  # Draws the background
        pygame.draw.circle(surface, BLACK, (150, 150), 50)
        pygame.draw.circle(surface, BLACK, (150, 600-150), 50)
        pygame.draw.circle(surface, BLACK, (600-150, 150), 50)
        pygame.draw.circle(surface, BLACK, (600-150, 600-150), 50)
        pygame.draw.circle(surface, BLACK, (300, 300), 50)

    def six(self, surface):#method to draw six die
        surface.fill(BLACK)
        pygame.draw.rect(surface, WHITE, (10, 10, 575, 575))  # Draws the background
        pygame.draw.circle(surface, BLACK, (200, 150), 50)
        pygame.draw.circle(surface, BLACK, (400, 150), 50)
        pygame.draw.circle(surface, BLACK, (200, 300), 50)
        pygame.draw.circle(surface, BLACK, (400, 300), 50)
        pygame.draw.circle(surface, BLACK, (200, 450), 50)
        pygame.draw.circle(surface, BLACK, (400, 450), 50)

class button(pygame.sprite.Sprite):#button class
    def __init__(self, x, y, w, h, text, bg, hover, action=None, textColor=BLACK):
        super().__init__()#init spirte
        self.x = x#declare variables
        self.y = y
        self.w = w
        self.h = h
        self.text = text
        self.bg = bg
        self.hover = hover
        self.action = action
        self.clickAble = True
        self.locked = False
        self.textColor = textColor
        self.return_button = False

    def lockAll(self, list):#method to lock all buttons
        global return_button
        return_button = True
        for x in list:
            if x.text != "Return":
                x.locked = True

    def press(self):#on button press
        global values#get reference to global variables
        global point_sum
        global state
        global dice
        global buttonsS2
        global rolls
        global return_button
        if self.action == "roll":#if roll button
            global dice
            if len(dice) == 0:#if there are no dice
                [dice.add(x) for x in diceRef]#add dive
            else:#if there are roles left
                for x in dice:#for each dice
                    if x.locked == False:#if not locked
                        x.roll()#roll
                rolls-=1#subtract amount of roles left
                if rolls == 0:#if no roles left
                    self.locked = True#lock roll button
                    buttons.add(button(450, 400, 100, 50, "Continue", GRAY, DGRAY, "continue"))#open a new button to move to the next scene
        elif self.action == "continue":#if continue button
            state=2#move to game state 2 (score adding)
            self.kill()#destory button
        elif self.action == "return":#if return button
            state=1#change to rolling state
            rolls = 3#reset rolls
            return_button = False#no return button (lets buttons update again0
            for x in dice:#for each dice
                x.locked = False#unlock dice
                x.roll()#roll the dice
            for x in buttons:#for each buttons in main state
                x.locked = False#unclock
            self.kill()#kill button

        elif self.action == "ones":#if action ones
            totals["ones"][0] += 1*values.count(1)#add values
            point_sum += 1*values.count(1)
            totals["ones"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "twos":#twos clicked
            totals["twos"][0] += 2 * values.count(2)#add values
            point_sum += 1 * values.count(2)
            totals["twos"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "threes":#threes clicked
            totals["threes"][0] += 3 * values.count(3)#add values
            point_sum += 1 * values.count(3)
            totals["threes"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "fours":#fours clicked
            totals["fours"][0] += 4 * values.count(4)#add values
            point_sum += 1 * values.count(4)
            totals["fours"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "fives":#fives clicked
            totals["fives"][0] += 5 * values.count(5)#add values
            point_sum += 1 * values.count(5)
            totals["fives"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "sixes":#sixes clicked
            totals["sixes"][0] += 6 * values.count(6)#add values
            point_sum += 1 * values.count(6)
            totals["sixes"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "three_of_a_kind":#three of a kind clicked
            totals["three_of_a_kind"][0] += sum(values)#add values
            point_sum += sum(values)
            totals["three_of_a_kind"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "four_of_a_kind":#four of a kind clicked
            totals["four_of_a_kind"][0]+= sum(values)#add values
            point_sum += sum(values)
            totals["four_of_a_kind"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "full_house":#full house clicked
            totals["full_house"][0]+= 25#add values
            point_sum += 25
            totals["full_house"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "small_straight":#small straight clicked
            totals["small_straight"][0] += 30#add values
            point_sum += 30
            totals["small_straight"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "large_straight":#large straight clicked
            totals["large_straight"][0] += 40#add values
            point_sum += 40
            totals["large_straight"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "chance":
            totals["chance"][0] += sum(values)#add values
            point_sum += sum(values)
            totals["chance"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)

        elif self.action == "yahtzee":
            totals["yahtzee"][0] += 50#add values
            point_sum += 50
            totals["yahtzee"][1] = True
            buttonsS2.add(button(475, 500, 75, 50, "Return", GRAY, DGRAY, "return"))#add return button
            self.lockAll(buttonsS2)


    def update(self, **kwargs):#update function (take any arguments with kwargs with erroring)
        global values#get global
        mouse = p.mouse.get_pos()#get mouse position

        if(self.x+self.w > mouse[0] > self.x) and (self.y + self.h > mouse[1] > self.y) or self.locked:#check if mouse is on the button
            p.draw.rect(screen, self.hover, (self.x, self.y, self.w, self.h))#draw darker background
            text_to_screen(self.text, self.x + (self.w / 2), self.y + (self.h / 2), self.textColor)#draw the text to screen
        else:
            p.draw.rect(screen, self.bg, (self.x, self.y, self.w, self.h))#draw normal background
            text_to_screen(self.text, self.x + (self.w / 2), self.y + (self.h / 2), self.textColor)#draw the text

state = 1#game state

dice = pygame.sprite.Group()#dice sprite group
diceRef = [Dice(100, 100), Dice(250, 100), Dice(400, 100), Dice(200, 250), Dice(350, 250)]#dice reference
buttons = pygame.sprite.Group()#buttons group
buttonsRef = [button(250, 400, 100, 50, "Roll", GRAY, DGRAY, "roll")]#buttons ref array
[buttons.add(x) for x in buttonsRef]#add all buttons to group
buttonsS2 = pygame.sprite.Group()#buttons for screen2
buttonsRefS2 = [button(400, 150, 50, 25, "Add", GRAY, DGRAY, "ones"),#all buttons for screen 2
                button(400, 180, 50, 25, "Add", GRAY, DGRAY, "twos"),
                button(400, 210, 50, 25, "Add", GRAY, DGRAY, "threes"),
                button(400, 240, 50, 25, "Add", GRAY, DGRAY, "fours"),
                button(400, 270, 50, 25, "Add", GRAY, DGRAY, "fives"),
                button(400, 300, 50, 25, "Add", GRAY, DGRAY, "sixes"),
                button(400, 330, 50, 25, "Add", GRAY, DGRAY, "three_of_a_kind"),
                button(400, 360, 50, 25, "Add", GRAY, DGRAY, "four_of_a_kind"),
                button(400, 390, 50, 25, "Add", GRAY, DGRAY, "full_house"),
                button(400, 420, 50, 25, "Add", GRAY, DGRAY, "small_straight"),
                button(400, 450, 50, 25, "Add", GRAY, DGRAY, "large_straight"),
                button(400, 480, 50, 25, "Add", GRAY, DGRAY, "chance"),
                button(400, 510, 50, 25, "Add", GRAY, DGRAY, "yahtzee")]
[buttonsS2.add(x) for x in buttonsRefS2]#add buttons to sprite group

values = [_.value for _ in diceRef]#get values of all die

#totals of all points and their catagory
totals = {"ones":[0, False], "twos":[0, False], "threes":[0, False], "fours":[0, False], "fives":[0, False], "sixes":[0, False], "three_of_a_kind":[0, False], "four_of_a_kind":[0, False], "full_house":[0, False], "small_straight":[0, False], "large_straight":[0, False], "chance":[0, False], "yahtzee":[0, False]}
point_sum = 0#point sum

FPS = 60
clock = p.time.Clock()

return_button = False

print("welcome to yahtzee!")#welcoming user
print("if you would like to know how to play, go check out https://cardgames.io/yahtzee/ and scroll down")
print("have fun!")

while running:#mian game loop
    for e in p.event.get():#for each event in the queue
        if e.type == p.QUIT:#if the event type is the quit event
            running = False#stop the main game loop
        if e.type == p.MOUSEBUTTONDOWN and e.button == 1:#if it is a click
            mouse = p.mouse.get_pos()#get mouse position
            for x in buttons:#for each button on screen 1
                if (x.x+x.w > mouse[0] > x.x) and (x.y + x.h > mouse[1] > x.y) and x.locked is False and state == 1:#if it is on a button and it it is o the r
                    x.press()
            for x in buttonsS2:
                if (x.x+x.w > mouse[0] > x.x) and (x.y + x.h > mouse[1] > x.y) and x.locked is False and state == 2:
                    x.press()
            for x in dice:
                if (x.x + 100 > mouse[0] > x.x) and (x.y + 100 > mouse[1] > x.y):
                    x.locked = not x.locked

    screen.fill(WHITE)#fill the screen with WHITE
    if state == 1:
        dice.update()
        buttons.update()
        text_to_screen("Rolls: " + str(rolls), 50, 50, BLACK)
        values = [_.value for _ in diceRef]
        values.sort()

    elif state == 2:
        if not return_button:
            iter_variable = 0

            for x in buttonsRefS2:
                x.locked = False

            for x in range(1, 7):#ones through sixes check
                if values.count(x) == 0:
                    buttonsRefS2[x-1].locked = True
            for x in range(1, 7):
                temp = False
                if values.count(x) == 3:
                    for y in range(1, 7):
                        if values.count(y) == 2:
                            temp = True
                            buttonsRefS2[8].locked = False
                            break
                    else:
                        buttonsRefS2[8].locked = True
                    if temp == True:
                        break
                else:
                    buttonsRefS2[8].locked = True
            for x in range(1, 7):
                if values.count(x) >= 3:
                    break
            else:
                buttonsRefS2[6].locked = True

            for x in range(1, 7):
                if values.count(x) >=5:
                    break
            else:
                buttonsRefS2[-1].locked = True

            for x in range(1, 7):
                if values.count(x) >= 4:
                    break
            else:
                buttonsRefS2[7].locked = True

            buttonsRefS2[9].locked = True#small straight check
            for x in range(len(values)):
                counter = 0
                if values[(x+1)%len(values)] == values[x]+1:
                    prev = (x+1)%len(values)
                    if values.count(x) != 5:
                        y=0
                        while y<3:
                            if values[(prev+1)%len(values)] == values[prev]+1 or values[(prev+1)%len(values)] == values[prev]:
                                if values[(prev + 1) % len(values)] == values[prev]:
                                    y-1
                                prev = (prev+1)%len(values)
                            else:
                                break
                            y+1
                        else:
                            break

            if (values.count(1) > 0 or values.count(6) > 0) and values.count(2) > 0 and values.count(3) > 0 and values.count(4) > 0 and values.count(5) > 0:#large straight check
                pass
            else:
                buttonsRefS2[10].locked = True

            usedCounter = 0

            for x in totals:#lock locked buttons
                if totals[x][1] == True:
                    buttonsRefS2[iter_variable].locked = totals[x][1]
                iter_variable+=1

            for x in buttonsRefS2:#increase used counter
                if x.locked == True:#if button is locked
                    usedCounter+=1

            if usedCounter == 13:#if all are used, exit game
                running = False

        draw_var = 150#draw variables to draw the buttons and blanks to screen
        draw_var_num = 148
        for x in totals:
            text_to_screen(x.replace("_", " "), 100, draw_var, BLACK, False)
            text_to_screen(str(totals[x][0]), 300, draw_var_num, BLACK, False)
            draw_var+=30
            draw_var_num+=30
        buttonsS2.update()

    #for x in range():


    display.update()

    clock.tick(FPS)  # tick

print("you achieved a high score of ", point_sum)
print("thanks for playing")

p.quit()
quit()

# # Modifications: