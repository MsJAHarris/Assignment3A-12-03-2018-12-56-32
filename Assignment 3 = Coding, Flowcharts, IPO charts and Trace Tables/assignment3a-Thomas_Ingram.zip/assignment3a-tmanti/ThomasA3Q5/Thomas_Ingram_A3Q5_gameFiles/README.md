# game
fortnitemmorpg lol

# Just a game made with python
not much special, just a game made with  python, using pygame.
sprites are done myself, also there is a game server so thats neat
