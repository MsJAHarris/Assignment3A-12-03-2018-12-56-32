# A very basic version of hangmen - version 2
# you always begin with a very basic functioning program, then add
# at each stage we will add something, more complex to the program.
# we have removed the hardcoded a word.
# we will be reading in one of many files depending upon user , could use tKinter for an option box
# we will be adding graphics, very basic at first then more elaborate
# we will add letter's guessed, tries remaining etc.


#importing the time module and random to pick a word from our text file
import time
import random
import pygame
import threading


# set up paths used to collect the word for our game
path = 'words.txt'

threads = []
# reading the file the path is currently hardcoded for one file, fruit.txt
# and we randomly pick a word
# before we pick a word, we need to know how large out file is
# I've done both in one step with a function, thinking ahead to later improvements

def generate_the_word(infile):
    try:
        with open(path) as f:           # using path in this way, we can later ask the user
            contents_of_file = f.read()
        lines = contents_of_file.splitlines()       # do you remember what splitlines does?
        line_number = random.randrange(0, len(lines))# you've seen this, going from the beginning, 0 to the last line
        f.close()
        return lines[line_number]       # returns our new word - line_number is defined in I/O
    except:
        print("file empty or not found")
        exit()
#determine the number of turns

turns = 10
guesses = set()
correctSet = set()
won = False

# Create a while loop
def userInput():
    global turns
    global guesses
    global running
    global won

    while turns > 0 and running:
        if not running:
            break

        # make a counter that starts with zero
        correct = 0

        #DRAWING OF LETTERS MOVED TO PYGAME SECTION
        # for every character in secret_word
        for char in guesses:
            # see if the character is in the players guess
            #all drawing will be done in main game loop
            if char in wordLetterSet:

                correct += 1

                # if failed is equal to zero

            #ADD WHAT WE NEED TO DRAW HERE

        # print You Won
        if correct == len(wordLetterSet):
            print("You won")
            won = True
            # exit the script
            break

        guess = input("Guess the phrase: ")

        #print you win
        if guess == word:
            print("you won")
            won = True
            break #exit the script

        # if the guess is not found in the secret word
        if guess not in word:

            # turns counter decreases with 1 (now 9)
            turns -= 1

            # print wrong
            print("Wrong")
            # how many turns are left
            print("You have", + turns, 'more guesses')

            # if the turns are equal to zero
            if turns == 0:
                print("You Lose")
                #to check if the player wants to play again
                while True:
                    tryAgain = input("would you like to try again (Y/N)").lower()#get input and make it lower case
                    if tryAgain in ["yes", "y"]:
                        startGame()#start the game again
                        break#break out of this loop
                    elif tryAgain in ["no", "n"]:
                        print("thanks for playing!")
                        running = False#stop the main game loop
                        break#break out of this
        else:
            print("Correct")
        if len(guess) == 1:
            guess = list(guess)  # seperate all characters in the variable guess into a list
            [guesses.add(x) for x in guess]  # add each letter into the guessed letters set


    while True:#check if player wants to play again
        playAgain = input("would you like to play again? (Y/N)").lower()
        if playAgain in ["yes", "y"]:
            startGame()
            running = True
            break
        elif playAgain in ["no", "n"]:
            print("Thanks for playing")
            running = False
            break
        else:
            print("that is not a valid answer try again")

                #welcoming the user

def setup():
    name = input("What is your name? ")

    print("Hello, " + name)
    print("Time to play hangman!")

    print(" ")

    # wait for 1 second
    time.sleep(1)

    print("Start guessing...")
    time.sleep(0.5)

    startGame()

def startGame():
    #reset variables
    global turns
    turns = 10
    global guesses
    guesses = set()
    global won
    won = False
    # regenerate word
    global word
    word = generate_the_word(path)

    global wordLetterSet
    wordLetterSet = set()
    [wordLetterSet.add(x) for x in word]

    # start the guessing thread
    guessingThread = threading.Thread(target=userInput)
    time.sleep(0.5)
    guessingThread.start()
    threads.append(guessingThread)

#pygame initilization
p = pygame

p.init()
p.font.init()

#colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
myfont = pygame.font.SysFont('monospace', 15)

#setting up the screen
(width, height) = (600, 600)

display = p.display
screen = display.set_mode((600, 600))
display.set_caption("Thomas Ingram A2Q2 - Hangman")

#running variable
running = True

setupThread = threading.Thread(target=setup)#setup the setup thread
setupThread.start()#start it
threads.append(setupThread)#append reference to thread to list

word = ""
wordLetterSet = set()

while running:#main game loop
    for e in p.event.get():#for each event in the queue
        if e.type == p.QUIT:#if the event type is the quit event
            running = False#stop the main game loop

    screen.fill(WHITE)#fill the screen with white

    if turns < 10 and turns > 0 and not won:
        hangman = pygame.image.load("Thomas_Ingram_" + str(10-turns) + "W.png")#load the image
        hangman = pygame.transform.scale(hangman, (200, 200))#scale the image
        screen.blit(hangman, (400-100, 250-40))#draw the image

    guessed = ""#guessed string
    correctStr = ""#correct characters string

    for x in guesses:  # for each letter in the guessed string
        guessed += x + ", "  # add all guessed strings to the gussed strings

    if won:
        textsurface = myfont.render("you won", 1, BLACK)  # render the text surface
        screen.blit(textsurface, (250, 300))  # draw it
    elif turns != 0:
        textsurface = myfont.render("Guessed: " + guessed[:-2], 1, BLACK)#render the text surface
        screen.blit(textsurface, (300-len(guessed)*5, 100))#draw it
        pygame.draw.line(screen, BLACK, (200, 600), (200, 200), 5)  # draw the hang mans noose
        pygame.draw.line(screen, BLACK, (200, 200), (400, 200), 5)
        pygame.draw.line(screen, BLACK, (400, 200), (400, 250), 5)
        for x in word:
            if x in guesses or x == " ":
                correctStr += " "+x+" "
            else:
                correctStr += " _ "
        textsurface = myfont.render("Word: " + correctStr, 1, BLACK)  # render the text surface
        screen.blit(textsurface, (400 - len(correctStr) * 5, 500))  # draw it
    elif turns == 0:
        textsurface = myfont.render("you lose", 1, BLACK)  # render the text surface
        screen.blit(textsurface, (250, 300))  # draw it

    display.update()#update the screen
    time.sleep(0.05)#sleep

#closing out of the game is quite slow and kinda buggy because there is no effective way to simply end threads.

for x in threads:#for each threads
    x.join()#join the thread to the main thread
p.quit()#quit pygame
quit()#quit the program

#check if the turns are more than zero

