# Problem Description:
# Please create a flowchart, IPO chart and trace table for a particular error you had while creating
# your work.  Please let me know which version you were on so that I may see the code and match up
# the trace table to that (now fixed) code.
#
# Your task:
# Create ONE of TWO games using the Card class you and your classmates created.
#
# More difficult option, (full marks possible). You will create the game of 21 or Blackjack,
# also using the Card class created in class. You will need complete instructions for your user.
# Date Begun:

# Programmer:
#imports
import turtle
import random
from ThomasA3Q4.Thomas_Ingram_CardClassTurtle import Card
import time

t = turtle#setting up turtle

screen = t.Screen()
screen.screensize(500, 500)
screen.setup(width=1.0, height=1.0, startx=None, starty=None)
width, height = screen.window_width(), screen.window_height()

p = t.Pen()#setting up the pen
p.speed("fastest")
p.penup()
p.hideturtle()

class BlackJackCard(Card):#card class
    def __init__(self, x, y, dealer=False, hidden=False):#overwridden init
        self.value = random.randint(1, 13)#select value and suit
        self.suit = random.randint(1, 4)
        self.weight = 0#setup other variables
        self.hidden = hidden
        self.x = x
        self.y = y
        if self.value in range(2, 11):#decide the points of the cards
            self.weight=self.value
        elif self.value == 1:
            if dealer and dealerSum+11 > 21:
                self.weight = 1
            elif dealer and dealerSum+11 < 21:
                self.weight = 11
        elif self.value in range(11, 14):
            self.weight = 10

    def evalAce(self):#method to evaluate the ace value
        if self.value == 1:#
            if dealer and dealerSum+11 > 21:
                self.weight = 1
            elif dealer and dealerSum+11 < 21:
                self.weight = 11
            elif playerSum+11 > 21:
                self.weight = 1
            elif playerSum+11 < 21:
                self.weight = 11

    def draw(self, x, y, scale):#draw function
        p.penup()#penup
        if not self.hidden:#if not hidden
            if self.suit == 1:#if suit 1-4 draw respective character
                p.setpos(x+2*scale, y-11*scale)
                p.write("♠", align="center", font=("Arial", 10*scale, "normal"))
            elif self.suit == 2:
                p.setpos(x+3*scale, y-11*scale)
                p.write("♥", align="center", font=("Arial", 10*scale, "normal"))
            elif self.suit == 3:
                p.setpos(x+3*scale, y-11*scale)
                p.write("♣", align="center", font=("Arial", 10*scale, "normal"))
            elif self.suit == 4:
                p.setpos(x+2*scale, y-11*scale)
                p.write("♦", align="center", font=("Arial", 10*scale, "normal"))

            if self.value == 1:#if value 1-13 setpos draw respective value symbol
                p.setpos(x+10*scale, y-20*scale)
                p.write("A", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 2:
                p.setpos(x+10*scale, y-20*scale)
                p.write("2", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 3:
                p.setpos(x+10*scale, y-20*scale)
                p.write("3", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 4:
                p.setpos(x+10*scale, y-20*scale)
                p.write("4", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 5:
                p.setpos(x+10*scale, y-20*scale)
                p.write("5", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 6:
                p.setpos(x+10*scale, y-20*scale)
                p.write("6", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 7:
                p.setpos(x+10*scale, y-20*scale)
                p.write("7", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 8:
                p.setpos(x+10*scale, y-20*scale)
                p.write("8", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 9:
                p.setpos(x+10*scale, y-20*scale)
                p.write("9", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 10:
                p.setpos(x+10*scale, y-20*scale)
                p.write("10", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 11:
                p.setpos(x+10*scale, y-20*scale)
                p.write("J", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 12:
                p.setpos(x+10*scale, y-20*scale)
                p.write("Q", align="center", font=("Arial", 10*scale, "normal"))
            if self.value == 13:
                p.setpos(x+10*scale, y-20*scale)
                p.write("K", align="center", font=("Arial", 10*scale, "normal"))

            p.setpos(x - 8, y + 5)#set the position
            p.pendown()#pendown
            for x in range(2):#draw the box
                p.forward(25 * scale)
                p.right(90)
                p.forward(35 * scale)
                p.right(90)
        else:#if hidden
            p.setpos(x - 8, y + 5)#just draw the box
            p.pendown()
            for x in range(2):
                p.forward(25 * scale)
                p.right(90)
                p.forward(35 * scale)
                p.right(90)
        p.penup()

print("In order to win, the player has to be closer to 21 than the dealer, without going over")#welccoming and explaining rules
print("")

print("you have two choices to hit or stand")
print("hit (1 key): get another card")
print("stand (2 key): keep your current cards and do nothing")

dealerSum = 0#setting up dealer and player cards
dealer = [BlackJackCard(-400, 400), BlackJackCard(-300, 400, hidden=True)]
for x in dealer:
    dealerSum += x.weight
dealerStood =False
playerSum = 0#player cards
playerCards = [BlackJackCard(-400, -250, True), BlackJackCard(-300, -250, True)]
for x in playerCards:
    playerSum += x.weight
playerStood = False

turn = 1 #1 is player, 2 is dealer
running = True#variables
playerWin = False
dealerWin = False

def evaluate():#to check if someone won
    global  running
    global playerWin
    global dealerWin

    if playerSum > 21:#if player busts
        dealerWin = True#dealer wins
        running = False
    elif dealerSum > 21:#if dealer busts
        playerWin = True#player wins
        running = False
    elif len(playerCards) == 2 and playerSum == 21:#if player wins off the bat
        playerWin = True#player wins and end game
        running = False
    elif len(dealer) == 2 and dealerSum == 21:#if dealer wins off the bat
        dealerWin = True#dealer wins and end game
        running = False
    elif playerStood and dealerStood:#if player stands and dealer stands
        if abs(21-playerSum) > abs(21-dealerSum):#if player wins
            playerWin = True#end game
            running = False
        else:#if dealer wins
            dealerWin = True#end game
            running = False

def hitormiss():#hit function
    global turn#globals
    if turn == 1:#if player turn
        playerCards.append(BlackJackCard(-400+ 100*len(playerCards)+1, playerCards[0].y))#add card to player
        evaluate()#evaluate
        turn = 2#switch turns
    elif turn == 2:#if dealer turn
        dealer.append(BlackJackCard(-400+ 100*len(dealer)+1, dealer[0].y, hidden=True))#add card to dealer
        evaluate()#evaluate
        turn = 1#switch turns

def stand():#stand
    global turn#globals
    global playerStood
    global dealerStood
    if turn == 1:#if player is standing
        playerStood = True#stand player
        evaluate()#eval match
        turn = 2#switch turns
        p.penup()#write player stood
        p.setpos(-350, -100)
        p.write("Player Stood", align="center", font=("Arial", 20, "normal"))
    elif turn == 2:#if dealer stands
        dealerStood = True#dealer stand
        evaluate()#eval match
        turn =1#switch turns
        p.penup()#write dealer stood
        p.setpos(-350, 100)
        p.write("Dealer Stood", align="center", font=("Arial", 20, "normal"))

def endGame():#function to end the game
    global running#global
    print("thanks for playing")#say bye
    running = False#exit maing ame loop

while running:#game loop
    for x in dealer:#for each card in dealers hand
        x.draw(x.x, x.y, 4)#draw it
    for x in playerCards:#for each card in
        x.draw(x.x, x.y, 4)#draw
    playerSum = 0
    dealerSum = 0
    for x in playerCards:#for each player card
        x.evalAce()#evaluate the aces
        playerSum += x.weight#update the weight
    for x in dealer:#for each dealer
        x.evalAce()#evalute aces
        dealerSum += x.weight#update the weight

    if turn == 1:#if player turn
        if playerStood:#switch turns
            turn = 2
        else:
            p.setpos(0, 0)#write instructions
            p.write("press (1) key to hit, press (2) key to stand, and press (0 to quit)", align="center", font=("Arial", 20, "normal"))

            screen.listen()#wait for key bind
            screen.onkeypress(hitormiss, "1")
            screen.onkeypress(stand, "2")
            screen.onkeypress(endGame, "0")

    elif turn == 2:#if dealer turns
        if dealerSum <= 17:
            hitormiss()#hit function
            print(dealerSum)
        elif dealerSum > 17:
            stand()#stand function

print("Thanks for playing")#bye to user

if playerWin:#if player won
    print("You Win!")#congratulate
elif dealerWin:#dealer win
    print("you lose")
else:
    print("you tied")#you tied

screen.bye()#close screen
quit()#quit
# Modifications: