"""1)	Recursion – The Koch curve is described in terms of “levels” or “degrees”."""

#Problem Description: The Koch curve of degree 0 is a straight line.  The first degree curve
# is formed by placing an accent (^).  The original line has been divided into 4( -^-), each of which
# is 1/3 the length of the original.  The accent or accent rises at 60 degrees, so it forms two sides
# of an equilateral triangle.  To get a second-degree curve, you put an accent in each of the line
# segments of the first-degree curve.  Successive curves are constructed by placing accents on each
# segment or the previous curve.
#Your Task:
#1.	 Create a flowchart for this problem
#2.	Create an IPO chart for this problem
#3.	Create a trace (table in any form) for this question when you have an error and hand it in.
#4.	Complete the coding and hand it in.

#Implement this algorithm with a Turtle class that contains instance variables location (a point) and
# Direction (a float?) and moveTo (somePoint), draw (length), and turn (degrees). A little advanced
# math if you are stuck (you do not need to use this):
#If you are maintaining direction as an angle in radians, the point you are going to can be computed
# from your current location direction x = length * cos(direction) and current location direction
# y = length * sin(direction)
#
#IMPORTANT NOTE:  Contrary to all other assignments, your Koch snowflake can be very basic and it will
# be marked as a level 3 if you have made an honest attempt (Application and Thinking).  You must have
# a base case and your program must end.  Use error capture.  BE very careful in your attempt to earn
# a Level 4 – you must cite your sources AND must not borrow more than 25% of your code.


#A turtle always knows where it currently sits and what direction it is facing.  To draw a Koch curve
# of a given length and degree, you might (but don’t need to) use an algorithm like:
# REMINDER - Rename this file appropriately.
# Date Begun:

# Programmer:

#imports
import turtle, threading, queue
import time

t = turtle#reference to turtle

action_queue = queue.Queue()#create a queue for the actions

pens = queue.Queue()#create a queue of pens
for _ in range(100):#add 10 to queue
    temp_pen = t.Pen()
    temp_pen.hideturtle()
    pens.put(temp_pen)

class pos():#create position data type object
    def __init__(self, x, y):#on call
        self.x = x#set the x property of obj to x
        self.y = y#set y property to given y

dummy_pen = turtle.Pen()
dummy_pen.hideturtle()

class Koch():#Koch object
    def __init__(self, startPos, startAngle, sides):#when initialized
        self.x = pos(startPos[0], startPos[0])#store the start position
        self.angle = startAngle%360 #store the angle to go
        self.sides = sides
        self.angles = 360/sides

    def Draw(self, length, degree):#draw function
        self.pen = pens.get()#create a new pen
        action_queue.put(lambda: self.pen.speed("fastest"))#add changing the pens speed to action queue

        action_queue.put(lambda: self.pen.penup())#add pen pickup to action queue
        action_queue.put(lambda: self.pen.goto(self.pos.x, self.pos.y))#add move the pen to location to action queue
        action_queue.put(lambda: self.pen.pendown())#add pen putdown to action queue

        action_queue.put(lambda: self.pen.setheading(self.angle))#add changing degree to action queue

        for x in range(self.sides):# for the amount of requested sides
            self.drawKoch(length, degree)#draw the snow flake side
            action_queue.put(lambda: self.pen.right(self.angles))#rotate it to draw the next side

    def drawKoch(self, length, degree):#function to recursivley draw the snowflake
        # print("Koch", length, degree)
        time.sleep(0.05)#sleep to allow things to properly get put into the action queue
        if degree > 0:#base case
            for t in [60, -120, 60, 0]:#for each of these different degrees to turn
                self.drawKoch(length/3, degree-1)#recurse deeper
                def turning_func(deg):#a function to rotate the pen (to keep it in scope because by the time the action queue will execute it, t=0)
                    return lambda: self.pen.left(deg)#return the lamda to turn with proper scoping
                action_queue.put(turning_func(t))#add the returned lamda to the action queue
        else:#if base case is met
            action_queue.put(lambda: self.pen.forward(length))#move forward (to end the recursion)

class commandHandler():#class for handling and storing commands
    class command():#a base command class
        def __init__(self, name, usage, description):#init
            self.name = name#assign name
            self.usage = usage#assign usage
            self.desc = description#assign description

        def Call(self):#an overrideable method
            pass

    class helpcmd(command):#help command that inherits the command class
        def Call(self, commands):#over ridden method of call
            for cmd in commands:#for each command
                print(commands[cmd].name + ":")#print the command name
                print(" usage: " + commands[cmd].usage)#print the command usage
                print(" description: " + commands[cmd].desc)#print the command description
    helpCommand = helpcmd("help", "help", "displays all commands and how to use them")#initialize the command

    exitCommand = command("exit", "exit", "exits the program")#initialize the command

    class drawcmd(command):#draw command
        def Call(self, args = []):#overridden method of call, args = [[posx, posx], facing, length of sides, sides
            if args:#if there are arguments
                try:#try this
                    koch = Koch([args[0], args[1]], args[2], args[5])#create a new koch, specifying its location, rotation, and size
                    koch.Draw(args[3], args[4])#draw the koch giving it the side length and degree
                except:
                    print("Something went wrong! try again")#telling the user something went wrong
                    print("make sure all parameters are numbers!")
                    print("usage: " + self.usage)#printing the usage just in case they wrote wrong

    drawCommand = drawcmd("draw", "draw <x starting coordinate> <y starting coordinate> <direction facing> <length of segments> <amount of degree> <amount of sides>", "draw a customizable koch, just call koch with no arguments to see an example")#initialize the draw command

class Client():#client object
    cmdHandler = commandHandler()#create a new reference to the command handler
    commands = {"help": cmdHandler.helpCommand, "exit": cmdHandler.exitCommand, "draw" : cmdHandler.drawCommand}#dict of commands and references to them

    threads = []#currently running turtle threads

    def handler(self):#command handler method
        print("Welcome to Thomas's Koch snowflake program!")#greeting user
        print("to view available commands type help")#tells them about the help command
        print("when you want to exit the program type stop/exit")
        while True:#main command loop
            temp = input().split()#get input
            run = True#a error checking variable
            if not len(temp) == 0:#if there was a command
                command_name = temp[0]#get the command anme
                args = []#create an aguments array
                if len(temp) > 1:#if there are arguments
                    args = temp[1:]#set any variable after the first indicie into the arguments array
                    try:#try this
                        args = [int(x) for x in args]#list comprehension to turn all arugments to numbers
                    except:#if it errored turning things to numbers
                        run = False#error checking variables ton false

                if command_name == "help":#if they want to call the command help
                    self.cmdHandler.helpCommand.Call(self.commands)#call the help command with our dictionary of commands
                elif (command_name == "exit" or command_name == "stop"):#if they want to exit the program
                    print("thank you, goodbye")#user IO
                    break#exit out of the command loop
                elif command_name == "draw":#draw command
                    if len(args) == 6 and run:#if there are 6 arguments and they are valid
                        new_thread = threading.Thread(target=self.cmdHandler.drawCommand.Call, args=[args])#create a new command thread
                        new_thread.start()#start the thread
                        self.threads.append(new_thread)#append a reference to the thread in the list
                    else:#if arguments were in properley called/used
                        print("please ensure all arguments are numbers")#IO
                        print("Improper usgae: " + self.commands["draw"].usage)#print the usage
        for inner_thread in self.threads:#for all active threads
            inner_thread.join()#stop them
        clientThread.join()

client = Client()#create a new client
clientThread = threading.Thread(target=client.handler)#begin threading the handler
clientThread.start()#start the client

# Process our action queue
while True:
    dummy_pen.left(1)
    try:
        action = action_queue.get(timeout=0.1)#get the action
        action()#run the action

    except:
        pass

    if not clientThread.isAlive():
        break
#(Idea copied from Prof. John Zelle, Python Programming and introduction to computer science 2nd
# edition {Python 2}.)